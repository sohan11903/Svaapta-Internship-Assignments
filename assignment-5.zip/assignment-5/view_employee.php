<?php
// Database connection
include('connect_database.php');


if (isset($_GET['id'])) {
    $employee_id = $_GET['id'];

    $sql = "SELECT * FROM user_data WHERE id = $employee_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "No employee found with this ID.";
        exit;
    }
} else {
    echo "Invalid request.";
    exit;
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Employee Details</title>
    <link rel="stylesheet" href="all_css/view_detail.css">
</head>

<body>
    <div class="card">
        <h2>View Employee Details</h2>

        <form method="POST" enctype="multipart/form-data">
            <div class="profile-picture">
                <img src="<?php echo $row['profile_pic']; ?>" alt="Profile Picture">
            </div>

            <label for="first_name">First Name:</label>
            <p><?php echo $row['first_name']; ?></p>

            <label for="last_name">Last Name:</label>
            <p><?php echo $row['last_name']; ?></p>

            <label for="email">Email:</label>
            <p><?php echo $row['email']; ?></p>

            <label for="gender">Gender:</label>
            <p><?php echo $row['gender']; ?></p>

            <label for="address1">Address:</label>
            <p><?php echo $row['address1']; ?></p>
            <p><?php echo $row['address2']; ?></p>

            <label for="technology">Technology:</label>
            <p><?php echo $row['technology']; ?></p>

            <div class="location-container">
                <div>
                    <label for="country">Country:</label>
                    <p><?php echo $row['country']; ?></p>
                </div>
                <div>
                    <label for="state">State:</label>
                    <p><?php echo $row['state']; ?></p>
                </div>
                <div>
                    <label for="city">City:</label>
                    <p><?php echo $row['city']; ?></p>
                </div>
            </div>

            <label for="username">Username:</label>
            <p><?php echo $row['username']; ?></p>

            <div class="button-container">
                <button class="view"><a href="display_details.php">Cancel View</a></button>
                <!-- <button class="view" onclick="window.location.href='display_details.php'">Cancel View</button> -->
            </div>
        </form>
    </div>
</body>

</html>
